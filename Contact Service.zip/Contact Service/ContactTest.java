import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ContactTest {

    @Test
    void testContactCreation() {
        String contactID = "ABCD123456";
        String firstName = "Michael";
        String lastName = "Williams";
        String phone = "1234567890";
        String address = "456 Maple Avenue";

        Contact contact = new Contact(contactID, firstName, lastName, phone, address);

        assertEquals(contactID, contact.getContactID());
        assertEquals(firstName, contact.getFirstName());
        assertEquals(lastName, contact.getLastName());
        assertEquals(phone, contact.getPhone());
        assertEquals(address, contact.getAddress());
    }

    @Test
    void testContactIDValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Lucas", "Brown", "0987654321", "789 Oak Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "Sophia", "Johnson", "0987654321", "987 Birch Lane"));
    }

    @Test
    void testPhoneNumberValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "Emily", "Clark", "12345", "654 Pine Road"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "Alex", "Taylor", null, "321 Cedar Court"));
    }
}