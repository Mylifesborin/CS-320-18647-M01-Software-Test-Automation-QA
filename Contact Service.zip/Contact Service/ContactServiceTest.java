import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ContactServiceTest {

    @Test
    void testAddContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("9876543210", "Ethan", "Miller", "9876543210", "101 Cedar Drive");
        assertTrue(service.addContact(contact));
        assertNotNull(service.getContact("9876543210"));
    }

    @Test
    void testDeleteContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("5432167890", "Olivia", "Wilson", "5432167890", "222 Spruce Avenue");
        service.addContact(contact);
        assertTrue(service.deleteContact("5432167890"));
        assertNull(service.getContact("5432167890"));
    }

    @Test
    void testUpdateContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("2468101214", "Isabella", "Martinez", "2468101214", "789 Birch Lane");
        service.addContact(contact);

        assertTrue(service.updateContact("2468101214", "Lucas", "Smith", "1234567890", "987 Oak Street"));
        assertEquals("Lucas", service.getContact("2468101214").getFirstName());
        assertEquals("Smith", service.getContact("2468101214").getLastName());
        assertEquals("1234567890", service.getContact("2468101214").getPhone());
        assertEquals("987 Oak Street", service.getContact("2468101214").getAddress());
    }
}